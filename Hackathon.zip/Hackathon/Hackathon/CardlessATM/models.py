from django.db import models

# Create your models here.
class customer(models.Model):
    customerid = models.CharField(max_length=10)
    firstname = models.CharField(max_length=10)
    lastname = models.CharField(max_length=15)
    mobileno = models.CharField(max_length=13)

    def __str__(self):
        return self.firstname

