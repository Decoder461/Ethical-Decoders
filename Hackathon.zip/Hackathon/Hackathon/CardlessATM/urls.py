from django.urls import path
from . import views

urlpatterns = [
    path('', views.title),
    path('^submit', views.validatecustomer, name='submit'),
    path('^submit2', views.verification_otp, name='submit2'),
    path('^submit3', views.failcustomer, name='submit3'),
    path('^submit4', views.failotp, name='submit4'),
]