from django.shortcuts import render
from twilio.rest import Client
import random
import requests
import json

# Create your views here.

def title(request):
    return render(request, 'CardlessATM/Screen1.html')

# Your Account Sid and Auth Token from twilio.com/console
# DANGER! This is insecure. See http://twil.io/secure
def send_otp(request):
    if request.method == "POST":
        mobileno = request.POST["inputMobileNo"]
        print(mobileno)

    global otp
    otp = random.randint(1000, 9999)
    print(otp)

    # account_sid = 'ACc4d71d2eaf5642059b2318d134387610'
    # auth_token = '65e54e8878ad60ed4a09453ea63ec30f'
    # client = Client(account_sid, auth_token)
    #
    # message = client.messages \
    #     .create(
    #     body='Your OTP is - ' + str(otp),
    #     from_='+12569989767',
    #     # media_url=['https://c1.staticflickr.com/3/2899/14341091933_1e92e62d12_b.jpg'],
    #     to=mobileno
    # )
    #
    # print(message.sid)

def verification_otp(request):
    if request.method == "POST":
        otpsecurpin = request.POST
        otpgenerated = otpsecurpin['inputOTP']
        securid = otpsecurpin['inputsecurID']
        print(otpgenerated)
        print(otp)
        print(securid)
        if otpgenerated == str(otp) and int(securid) == 1234:
                # and securid == '9999':
            print('OTP and Secure ID verified')
            return render(request, 'CardlessATM/Screen3.html')
        else:
            print('OTP and Secure ID not verified')
            return render(request, 'CardlessATM/Screen5.html')

def failcustomer(request):
    return render(request, 'CardlessATM/Screen1.html')

def failotp(request):
    return render(request, 'CardlessATM/Screen2.html')

def validatecustomer(request):
    if request.method == "POST":
        customerid = request.POST['inputCustomerId']
        mobile_no = request.POST['inputMobileNo']
        response = requests.get('http://127.0.0.1:8000/customer/').json()
        a = json.dumps(response)
        b = json.loads(a)
        mobile_no = int(mobile_no)
        for i in range(7):
            if customerid == b[i]["customerid"]:
                customername = b[i]["firstname"]
                context = {"name": customername}
                send_otp(request)
                return render(request, 'CardlessATM/Screen2.html', context)
                break
        return render(request, 'CardlessATM/Screen4.html')
