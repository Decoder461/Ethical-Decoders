from django.apps import AppConfig


class CardlessatmConfig(AppConfig):
    name = 'CardlessATM'
